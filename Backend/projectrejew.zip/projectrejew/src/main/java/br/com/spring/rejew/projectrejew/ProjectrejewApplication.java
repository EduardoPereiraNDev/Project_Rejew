package br.com.spring.rejew.projectrejew;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProjectrejewApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProjectrejewApplication.class, args);
	}

}
